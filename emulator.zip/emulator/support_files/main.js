"use strict"

var disk_index;

var hash = gup('disk') || hup();

if (hash) {
	if(hash == "dos"){
		$.ajax({
			url: "support_files/all.js",
			dataType: 'script',
			success: loaded,
			async: true
		});
	} else {
		var files = hash.split('!');
		disk_index = [];
		for (var idx = 0; idx < files.length; idx++) {
			var file = files[idx];
			file = ((file.indexOf(".")>-1) ? file : 'json/disks/' + file + '.json');
			var _n = file.split('/').pop().split(".")[0].split("_");
			for(var i = 0; i < _n.length; i++){
				_n[i] = _n[i].charAt(0).toUpperCase() + _n[i].substring(1);
			}
			var name = String(_n.join(" "));
			var unique = true;
			for (var idy = 0; idy < disk_index.length; idy++) {
				if(file == disk_index[idy].filename){
					unique = false;
				}
			}
			if(unique){
				disk_index.push(
					{
						"filename": file,
						"e": true,
						"name": name,
						"category": "Disks"
					}	
				);
			}
		}
		loaded();
	}
} else {
	$.ajax({
		url: "support_files/index.js",
		dataType: 'script',
		success: loaded,
		async: true
	});
}

function loaded(){
	$.ajax({
		url: "support_files/main2.js",
		dataType: 'script',
		success: main2loaded,
		async: true
	});
}


function main2loaded(){
	//console.log("ready!");
}





