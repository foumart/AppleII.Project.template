"use strict"

if(!disk_index) disk_index = [
  {
     "filename": "json/disks/GRIDLOCK.dsk",
     "e": true,
     "name": "GridLock",
     "category": "Games"
  }
  
];
