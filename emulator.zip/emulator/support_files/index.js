"use strict"

if(!disk_index) disk_index = [
  
  {
     "filename": "json/disks/GRIDLOCK.dsk",
     "name": "Gridlock",
     "category": "Games"
  }
];
